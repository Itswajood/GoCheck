package gocheck;
import static gocheck.GoCheck.myAdmins;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class AccountGC {
    public Scanner input = new Scanner(System.in);

    Node head = null;
    Node tail = null;

    int size = 0;

    private class Node {

        private Node next, prev;

        private String fname;
        private String lname;
        private String age;
        private String gender;
        private String username;
        private String email;
        private String password;
        private String phoneNumber;



        public Node(String fname, String lname, String age, String gender, String username,String email, String password, String phoneNumber, Node next, Node prev) {
            this.next = next;
            this.prev = prev;
            this.fname = fname;
            this.lname = lname;
            this.age = age;
            this.gender = gender;
            this.username = username;
            this.email = email;
            this.password = password;
            this.phoneNumber = phoneNumber;
        }



        public Node() {

        }

        public String getFname() {
            return fname;
        }

        public void setFname(String fname) {
            this.fname = fname;
        }

        public String getLname(){
            return lname;
        }

        public void setLname(String lname) {
            this.lname = lname;
        }

        public String getAge() {
            return age;
        }

        public void setAge(String age) {
            this.age = age;
        }

        

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            boolean flag;

            do {
                flag = false;
                if (isUsernameUnique(username)) {
                    this.username = username;
                    flag = true;
                } else {
                    System.out.println("This username is already used, please try again.");
                    username = input.nextLine();
                }
            } while (!flag);

        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {

            boolean flag;
            do {
                flag = false;
                if (isEmailUnique(email) && checkEmail(email)) {
                    this.email = email;
                    flag = true;
                    break;
                } else if (!checkEmail(email)) {
                    System.out.println("You have entered an invalid email, kindly try again.");
                    email = input.nextLine();
                } else {
                    System.out.println("This Email is already used, please try again.");
                    email = input.nextLine();
                }
            } while (!flag);
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            boolean flag;

            do {
                flag = false;
                if (checkPassword(password)) {
                    this.password = password;
                    flag = true;
                    break;
                } else {
                    System.out.println("You have entered an invalid password, kindly try again.");
                    System.out.println(
                            "Hint: Your Password must:\n" +
                            "1- Be between 8 and 15 characters. \n" +
                            "2- Include at least one letter.\n" +
                            "3- Include at least one number.\n" +
                            "4- Include at least one symbol (@,#,%,$,&)\n");
                    password = input.nextLine();
                }

            } while (!flag);
        }

        public String getPhoneNumber() {
            return phoneNumber;
        }

        public void setPhoneNumber(String phoneNumber) {

            boolean flag;
            do {

                flag = false;

                if (checkPNumber(phoneNumber) && isPhoneNumberUnique(phoneNumber)) {
                    this.phoneNumber = phoneNumber;
                    flag = true;
                    break;
                } else if (!isPhoneNumberUnique(phoneNumber)) {
                    System.out.println("This Phone Number is already used, please try again.");
                    phoneNumber = input.nextLine();
                } else {
                    System.out.println("You have entered an invalid Phone Number, kindly try again." 
                            + "\nHint: Phone number must be a 10 digits:)");
                    phoneNumber = input.nextLine();
                }

            } while (!flag);
        }

        public Node getNext() {
            return next;
        }

        public void setNext(Node next) {
            this.next = next;
        }

        public Node getPrev() {
            return prev;
        }

        public void setPrev(Node prev) {
            this.prev = prev;
        }

        public String getGender() {
            return gender;
        }

        public void setGender(String gender) {
            this.gender = gender;
        }



    } // end node

    public AccountGC() {
    }

    public int getSize() {
        return size;
    }

    public boolean isEmpty() {
        return (size == 0);
    }

    public void addUser(Node newNode) {

        // this method will be called in createAccount() method
        if (isEmpty()) {
            head = newNode;
            tail = newNode;
            newNode.next = head;
            newNode.prev = head;
        } else {
            newNode.prev = head;
            tail.next = newNode;
            head.prev = newNode;
            newNode.next = head;
            tail = newNode;
        }
        size++;

        
    }

    public void find(String username) {

        if (isEmpty()) {
            System.out.println("The program has no users yet");
            return;
        }

        Node current = head;
        boolean found = false;

        do {
            if (current.getUsername().equals(username)) {
                System.out.println("The username " + username + " is found");
                found = true;
                return;
            }

            current = current.next;
        } while (current != head);

        if (!found) {
            System.out.println("The username " + username + " not found");
        }
    }

    public void dispalyAccounts() {

        if (isEmpty()) {
            System.out.println("The List is Empty!");
            return;
        }

        Node current = head;
        // int counter = 1;
        System.out.println("The Avaliable Accounts: ");

        do {
            System.out.println("username : " + current.getUsername());
            System.out.println("name: " + current.getFname() + " " + current.getLname());
            System.out.println("age: " + current.getAge());
            System.out.println("email: " + current.getEmail());
            System.out.println("phone number: " + current.getPhoneNumber());
            System.out.println("_________________________________________________");

            current = current.next;

        } while (current != head);

    }

    public void createAccount() {

        Scanner input = new Scanner(System.in);
        Node newNode = new Node();

        System.out.println("--- CREATING NEW ACCOUNT ---");
        System.out.println("Please Enter the needed data to create your account");
        System.out.println("first name: ");
        String fname = input.nextLine();
        newNode.setFname(fname);
        System.out.println("last name");
        String lname = input.nextLine();
        newNode.setLname(lname);
        System.out.println("age: ");
        String age = input.nextLine();
        newNode.setAge(age);
        System.out.println("gender: ");
        String gender = input.nextLine();
        newNode.setGender(gender);
        System.out.println("email: ");
        String email = input.nextLine();
        newNode.setEmail(email);
        System.out.println("password: ");
        String password = input.nextLine();
        newNode.setPassword(password);
        System.out.println("phone number: ");
        String phonenumber = input.nextLine();
        newNode.setPhoneNumber(phonenumber);
        System.out.println("username: ");
        String username = input.nextLine();
        newNode.setUsername(username);
        // input.nextLine();

        addUser(newNode);
    }

    private boolean isEmailUnique(String email) {
        if (isEmpty()) {
            return true; // No users in the system, so email is unique
        }

        Node current = head;
        do {
            if (current.getEmail().equalsIgnoreCase(email)) {
                return false; // Email already exists
            }
            current = current.next;
        } while (current != head);

        return true; // Email is unique
    }

    public boolean isPhoneNumberUnique(String phoneNumber) {
        if (isEmpty()) {
            return true;
        }
        Node current = head;
        do {
            if (current.getPhoneNumber().equals(phoneNumber)) {
                return false;
            }
            current = current.next;
        } while (current != head);
        return true;
    }

    public boolean isUsernameUnique(String username) {
        if (isEmpty()) {
            return true;
        }
        Node current = head;
        do {
            if (current.getUsername().equalsIgnoreCase(username)) {
                return false;
            }
            current = current.next;
        } while (current != head);
        return true;
    }

    public static boolean checkEmail(String email) {
        String emailRegex = "^[\\w.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}$";
        return email.matches(emailRegex);
    }

    public static boolean checkPassword(String password) { // method that return true only if the password is valid to
                                                           // the conditions
        // pass should be > 8 charecter
        // at least 1 letter
        // at least 1 number
        // at least one spical char (@ , & , %, $, #)

        boolean hasLetter = false;
        boolean hasNumber = false;
        boolean hasChar = false;

        if (password.length() >= 8 && password.length() <= 15) {

            for (int i = 0; i < password.length(); i++) {

                char ch = password.charAt(i); // to make strings to char

                if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {
                    hasLetter = true;
                } else if (ch >= '0' && ch <= '9') {
                    hasNumber = true;
                } else if (ch == '@' || ch == '#' || ch == '%' || ch == '$' || ch == '&') {
                    hasChar = true;
                }
            }
        }
        return hasLetter && hasNumber && hasChar;
    }

    public boolean validateUser(String username, String password){
        if (isEmpty()){
            System.out.println("No Accounts were founds");
            return false;
        }
        Node current = head;

        do {
            if (current.getUsername().equals(username) && current.getPassword().equals(password)){
                return true;
            }
            current = current.next;
        } while (current != head);

        return false;
    }

    public static boolean checkPNumber(String pNumber) {
        return pNumber.length() == 10; // true onlyif phone number is 10 digits
    }

    public void adminAccounts(){

        Node admin1 = new Node("Wajood", "Khalid", "21", "Female", "WajoodK", "2220001292@iau.edu.sa", "WKwk1234&", "0540326426", null, null);
        addUser(admin1);
        Node admin2 = new Node("Norah", "Alanzi", "21", "Female", "NorahAlanzi.51", "22200000572@iau.edu.sa", "No1222$#8935", "0551732744",null, null);
        addUser(admin2);
        Node admin3 = new Node("Nada","Alrshid","21","Female","Nada123","2220000552@iau.edu.sa","Nada34561","0543559646",null,null);
        addUser(admin3);
        Node admin4 = new Node("Lojain","Hafez","21","Female","Lojan23","2220000@iau.edu.sa","Lo456&","055555555",null,null);
        addUser(admin4);

    }
    
    
     

}
